
package collection;

public class SungJukMain {

	public static void main(String[] args) {
		SungJukService service = new SungJukService();
		service.menu();
		System.out.println("���α׷� ����");
	}

}
