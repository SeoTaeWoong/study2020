package collection;

public class SungJukDTO implements Comparable<SungJukDTO>{
	
	private int key;//��ȣ �Է� :
	private String name;//�̸� �Է� :
	private int kor;	//���� �Է� :
	private int eng;	//���� �Է� :
	private int math;	//���� �Է� :
	
	
	
	//public SungJukDTO() {
//		this.key = key;
//		this.name = name;
//		this.kor = kor;
//		this.eng = eng;
//		this.math = math;
	
	public SungJukDTO() {
		// TODO Auto-generated constructor stub
	}
	public void setKey(int key) {
		this.key = key;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public int getKey() {
		return key;
	}
	public String getName() {
		return name;
	}
	public int getKor() {
		return kor;
	}
	public int getEng() {
		return eng;
	}
	public int getMath() {
		return math;
	}	
	@Override
	public String toString() {
		return key+"\t"+name+"\t"+kor+"\t"+eng+"\t"+math;
	}
	
	@Override
	public int compareTo(SungJukDTO o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
